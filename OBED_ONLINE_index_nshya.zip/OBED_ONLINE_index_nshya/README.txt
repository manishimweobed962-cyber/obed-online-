OBED ONLINE - index.html nshya

Uko uyishyira kuri GitHub:
1. Kuramo iyi ZIP kuri telefone yawe uyifungure (Extract).
2. Fungura folder OBED_ONLINE_index_nshya.
3. Hitamo index.html.
4. Fungura https://github.com/manishimweobed962-cyber/obed-online-/upload
5. Upload index.html, hanyuma ukande Commit changes.

Icyitonderwa:
- Shyira index.html ku rwego rwa mbere rwa repository, ntuyishyire muri indi folder.
- Iyi ni website y'ibanze (static). Ntirimo Admin Dashboard, database cyangwa uburyo bwo kohereza amakuru kuri server.
- Ntushyire ku rubuga nimero cyangwa email byawe bwite utabanje kubiganiraho n'umubyeyi/umukurikirana wawe.
