OBED ONLINE — contact update
Iyi website irimo WhatsApp, email na contact form.
Iyo umuntu yuzuza contact form, WhatsApp irafunguka ifite ubutumwa; agomba gukanda Send muri WhatsApp.
Email link ifungura porogaramu ya email.

Kuvugurura GitHub:
1. Fungura repository yawe.
2. Hitamo Add file > Upload files.
3. Shyiramo iyi index.html nshya, isimbuze iya kera.
4. Kanda Commit changes.
Niba Netlify ihujwe na GitHub, website izivugurura ubwayo.

Icyitonderwa: Nimero na email biri kuri website bishobora kubonwa na buri wese. Saba umubyeyi/umurera kubyemeza mbere yo kubitangaza.
